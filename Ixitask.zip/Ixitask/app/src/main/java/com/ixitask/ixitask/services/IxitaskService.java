package com.ixitask.ixitask.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ixitask.ixitask.models.ResponseCode;
import com.ixitask.ixitask.models.ResponseHomepass;
import com.ixitask.ixitask.models.ResponseInstall;
import com.ixitask.ixitask.models.ResponseLogin;
import com.ixitask.ixitask.models.ResponseLogs;
import com.ixitask.ixitask.models.ResponseProduct;
import com.ixitask.ixitask.models.ResponseSlot;
import com.ixitask.ixitask.models.ResponseSummary;
import com.ixitask.ixitask.models.ResponseSummaryRes;
import com.ixitask.ixitask.models.ResponseUpdate;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

public class IxitaskService {

    public static final String BASE_URL = "http://www.ixitask.com/";

    /**
     * userid: 527
     * userkey: bcbac21ec237292b9ebbf98719a64007
     */
    public interface IxitaskApi {
        @Headers("Accept-Encoding: identity")
        @FormUrlEncoded
        @POST("/api/login")
        Call<ResponseLogin> userLogin(@Field("uname") String username,
                                      @Field("upass") String password);

        @Headers("Accept-Encoding: identity")
        @FormUrlEncoded
        @POST("/api/my_homepass")
        Call<ResponseHomepass> getHomepasses(@Field("userid") String id,
                                             @Field("userkey") String key);

        @Headers("Accept-Encoding: identity")
        @FormUrlEncoded
        @POST("/api/response_code")
        Call<ResponseCode> getResCodes(@Field("userid") String id,
                                       @Field("userkey") String key);

        @Headers("Accept-Encoding: identity")
        @FormUrlEncoded
        @POST("/api/update_homepass_activity")
        Call<ResponseUpdate> submitUpdate(@Field("userid") String userId,
                                          @Field("userkey") String userKey,
                                          @Field("hpid") String hpId,
                                          @Field("date") String date,
                                          @Field("contact_type") int contactType,
                                          @Field("owner_name") String ownerName,
                                          @Field("response_code") String resCode,
                                          @Field("note") String note,
                                          @Field("open") boolean isOpen,
                                          @Field("long") double lon,
                                          @Field("lat") double lat);

        @Headers("Accept-Encoding: identity")
        @FormUrlEncoded
        @POST("/api/activity_log")
        Call<ResponseLogs> getLogs(@Field("userid") String userId,
                                   @Field("userkey") String userKey,
                                   @Field("hpid") String hpId);

        @Headers("Accept-Encoding: identity")
        @FormUrlEncoded
        @POST("/api/track_user_location")
        Call<ResponseUpdate> updateLocation(@Field("userid") String userId,
                                            @Field("userkey") String userKey,
                                            @Field("lat") double lat,
                                            @Field("long") double lon);

        @GET("/mega/api/my_install")
        Call<ResponseInstall> getInstallation(@Query("userid") String userid,
                                              @Query("userkey") String userkey);

        @GET("/mega/api/activiy_summary")
        Call<ResponseSummary> getSummaries(@Query("userid") String userid,
                                           @Query("userkey") String userkey);

        @GET("/mega/api/activity_summary_response")
        Call<ResponseSummaryRes> getSummaryResponses(@Query("userid") String userid,
                                                     @Query("userkey") String userkey,
                                                     @Query("hpscid") int hpscId);

        @GET("/mega/api/slot")
        Call<ResponseSlot> getSlots(@Query("userid") String userid,
                                    @Query("userkey") String userkey,
                                    @Query("slotdate") String date);

        @GET("/mega/api/product")
        Call<ResponseProduct> getProducts(@Query("userid") String userid,
                                          @Query("userkey") String userkey);

        @Headers("Accept-Encoding: identity")
        @FormUrlEncoded
        @POST("/mega/api/register_install")
        Call<ResponseUpdate> registerInstall(@Field("userid") String userId,
                                             @Field("userkey") String userKey,
                                             @Field("slotid") String slotId,
                                             @Field("cust_name") String custName,
                                             @Field("longitude") double lon,
                                             @Field("latitude") double lat,
                                             @FieldMap Map<String, Integer> products,
                                             @FieldMap Map<String, String> bundles);

    }

    public static IxitaskApi getApi(){
        Gson gson = new GsonBuilder().setLenient().create(); //accept malformed json
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        return retrofit.create(IxitaskApi.class);
    }

}
