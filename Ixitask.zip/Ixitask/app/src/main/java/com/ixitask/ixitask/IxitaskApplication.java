package com.ixitask.ixitask;

import android.app.Application;

public class IxitaskApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
