package com.ixitask.ixitask.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionUtils {

    public static String[] allPermissions = new String[]{
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION};

    /**
     * check if some permissions is allowed by user
     * @param context context where the method is called
     * @param activity activity where the method is called
     * @param permissions the permissions to be checked
     * @return true if all permission are allowed
     */
    public static boolean isPermissionGranted(Context context, Activity activity, String... permissions){
        try {
            for (String s : permissions){
                if (ContextCompat.checkSelfPermission(context, s) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(activity, permissions, Constants.REQ_PERMISSION);
                    return false;
                }
            }
            return true;
        } catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }
}
