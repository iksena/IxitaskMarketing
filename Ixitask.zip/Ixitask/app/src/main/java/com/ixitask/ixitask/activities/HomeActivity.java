package com.ixitask.ixitask.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.annotation.NonNull;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.ixitask.ixitask.R;
import com.ixitask.ixitask.fragments.ActivityFragment;
import com.ixitask.ixitask.fragments.HomepassFragment;
import com.ixitask.ixitask.fragments.LogsFragment;
import com.ixitask.ixitask.models.ResponseHomepass;
import com.ixitask.ixitask.services.LocationRequestHelper;
import com.ixitask.ixitask.utils.Constants;
import com.ixitask.ixitask.utils.PermissionUtils;
import com.ixitask.ixitask.utils.ViewUtils;

import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.ixitask.ixitask.services.LocationRequestHelper.LOCATION_SINGLE_UPDATE_INTERVAL;
import static com.ixitask.ixitask.services.LocationRequestHelper.LOCATION_UPDATE_INTERVAL;
import static com.ixitask.ixitask.services.LocationRequestHelper.REQ_GPS_SINGLE;
import static com.ixitask.ixitask.services.LocationRequestHelper.REQ_GPS_TRACKING;
import static com.ixitask.ixitask.services.LocationRequestHelper.getLocationRequest;
import static com.ixitask.ixitask.services.LocationRequestHelper.getPendingIntent;
import static com.ixitask.ixitask.services.LocationRequestHelper.promptEnableGps;
import static com.ixitask.ixitask.utils.PermissionUtils.isPermissionGranted;

public class HomeActivity extends AppCompatActivity implements
        BottomNavigationView.OnNavigationItemSelectedListener,
        HomepassFragment.OnHomepassInteractionListener,
        ActivityFragment.OnActivityInteractionListener,
        LogsFragment.OnLogsInteractionListener {

    private static final String TAG = HomeActivity.class.getSimpleName();

    @BindView(R.id.navigation)
    BottomNavigationView navigation;
    @BindView(R.id.swipe)
    SwipeRefreshLayout swipeRefresh;
    @BindView(R.id.btn_settings)
    ImageView btnSettings;

    private String userId;
    private String userKey;
    private ResponseHomepass.Homepass homepass;
    private FusedLocationProviderClient locationProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ButterKnife.bind(this);

        checkUserValidity();
        if (!isPermissionGranted(this, this,
                PermissionUtils.allPermissions)) {
            if (getIntent() == null) finish(); //if doesn't come from LoginActivity
        }

        navigation.setOnNavigationItemSelectedListener(this);
        navigation.setSelectedItemId(R.id.navigation_home);
        btnSettings.setOnClickListener(v->startActivity(new Intent(this,
                SettingsActivity.class)));
        swipeRefresh.setOnRefreshListener(this::refreshFragment);
        ViewUtils.hideKeyboard(this, getCurrentFocus());

        //TO DO ask to enable GPS
        promptEnableGps(this, getLocationRequest(LOCATION_UPDATE_INTERVAL), REQ_GPS_TRACKING);
        locationProvider = LocationServices.getFusedLocationProviderClient(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        PreferenceManager
            .getDefaultSharedPreferences(this)
            .edit()
            .putString(Constants.ARG_USER_ID, userId)
            .putString(Constants.ARG_USER_KEY, userKey)
            .apply();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkUserValidity();
        handleLocationUpdate();

        //TODO expiration time bomb
//        Calendar expirationDate = Calendar.getInstance();
//        expirationDate.set(2018, Calendar.SEPTEMBER , 25);
//        if (Calendar.getInstance().compareTo(expirationDate) > 0) {
//            Toast.makeText(this,
//                    "Your testing session has expired. Please contact the developer.",
//                    Toast.LENGTH_SHORT).show();
//            finish();
//        }
    }

    @Override
    public void onBackPressed() {
        switch (navigation.getSelectedItemId()){
            case R.id.navigation_home:
                moveTaskToBack(true);
                break;
            case R.id.navigation_activity:
                navigation.setSelectedItemId(R.id.navigation_home);
                break;
            case R.id.navigation_logs:
                navigation.setSelectedItemId(R.id.navigation_home);
                break;
            default:
                moveTaskToBack(true);
                break;
        }

    }

    /**
     * validate user id and key stored in app
     * @return true if valid
     */
    private boolean checkUserValidity(){
        SharedPreferences sPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        userId = sPrefs.getString(Constants.ARG_USER_ID, "");
        userKey = sPrefs.getString(Constants.ARG_USER_KEY, "");
        if (userId.isEmpty() || userKey.isEmpty()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return false;
        }
        return true;
    }

    /**
     * handling live location tracking based on user settings
     */
    private void handleLocationUpdate(){
        SharedPreferences sPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean isTrackingLocation = sPrefs.getBoolean(getString(R.string.preference_key_location), true);
        if (isTrackingLocation) {
            requestLocationUpdate();
        } else {
            removeLocationUpdate();
        }
    }

    /**
     * run live location tracking on background
     */
    @SuppressLint("MissingPermission")
    private void requestLocationUpdate() {
        LocationRequestHelper.setRequesting(this, true);
        if (isPermissionGranted(this, this, PermissionUtils.allPermissions)){
            locationProvider.requestLocationUpdates(getLocationRequest(LOCATION_UPDATE_INTERVAL),
                    getPendingIntent(this));
        }

    }

    /**
     * stop live location tracking on background
     */
    private void removeLocationUpdate(){
        LocationRequestHelper.setRequesting(this, false);
        locationProvider.removeLocationUpdates(getPendingIntent(this));
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        switch (item.getItemId()) {
            case R.id.navigation_home:
                fragment = HomepassFragment.newInstance(userId, userKey);
                break;
            case R.id.navigation_activity:
                if (!isPermissionGranted(this, this,
                        PermissionUtils.allPermissions)){
                    Toast.makeText(this, R.string.error_permission, Toast.LENGTH_SHORT).show();
                    return false;
                }
                if (homepass!=null)
                    fragment = ActivityFragment.newInstance(userId, userKey,
                            homepass.getHpid(),
                            homepass.getStreetName(),
                            homepass.getOwner(),
                            homepass.getPhone(),
                            Boolean.parseBoolean(homepass.getOpen()));
                else
                    Toast.makeText(this, R.string.error_no_homepass, Toast.LENGTH_SHORT).show();
                break;
            case R.id.navigation_logs:
                if (homepass!=null)
                    fragment = LogsFragment.newInstance(userId, userKey,
                            homepass.getHpid(),
                            homepass.getStreetName(),
                            homepass.getOwner(),
                            homepass.getPhone());
                else
                    Toast.makeText(this, R.string.error_no_homepass, Toast.LENGTH_SHORT).show();
                break;
        }
        if (fragment!=null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_navigation, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    /**
     * refresh the current fragment displayed
     */
    private void refreshFragment(){
        onProgressLoading(true);
        String message = getString(R.string.error_no_response);
        //getting current fragment from the fragment container layout
        Fragment current = getSupportFragmentManager().findFragmentById(R.id.fragment_navigation);
        if (current != null){
            if (current instanceof HomepassFragment){
                ((HomepassFragment) current).setView();
            } else if (current instanceof ActivityFragment){
                ((ActivityFragment) current).setView();
            } else if (current instanceof LogsFragment){
                ((LogsFragment) current).setView();
            } else {
                Log.d(TAG, message);
                ViewUtils.dialogError(this,"Failed", message).create().show();
                onProgressLoading(false);
            }
        } else {
            Log.d(TAG, message);
            ViewUtils.dialogError(this,"Failed", message).create().show();
            onProgressLoading(false);
        }

    }

    @Override
    public void onHomepassClick(ResponseHomepass.Homepass homepass) {
        this.homepass = homepass;
        navigation.setSelectedItemId(R.id.navigation_activity);
    }

    @Override
    public void onActivitySubmit(String hpId) {
        if (Objects.equals(hpId, homepass.getHpid()))
            navigation.setSelectedItemId(R.id.navigation_logs);
        else
            Toast.makeText(this, R.string.error_no_homepass, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProgressLoading(boolean isLoading) {
        swipeRefresh.post(()->swipeRefresh.setRefreshing(isLoading));
        if (isLoading) ViewUtils.hideKeyboard(this, getCurrentFocus());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQ_GPS_TRACKING){
            if (resultCode == RESULT_OK){
                handleLocationUpdate(); //live location tracking
            } else {
                promptEnableGps(this, getLocationRequest(LOCATION_UPDATE_INTERVAL),REQ_GPS_TRACKING);
            }
        } else if (requestCode == REQ_GPS_SINGLE){
            if (resultCode == RESULT_OK){
                refreshFragment(); //single location for activity form submission
            } else {
                promptEnableGps(this, getLocationRequest(LOCATION_SINGLE_UPDATE_INTERVAL), REQ_GPS_SINGLE);
            }
        }
    }
}
