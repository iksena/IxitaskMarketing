package com.ixitask.ixitask.fragments;

import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ixitask.ixitask.R;
import com.ixitask.ixitask.models.ResponseInstall;

import java.util.List;

public class InstallationAdapter extends RecyclerView.Adapter<InstallationAdapter.ViewHolder> {

    private final List<ResponseInstall.Install> installs;

    public InstallationAdapter(List<ResponseInstall.Install> installs) {
        this.installs = installs;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_installation, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.install = installs.get(position);
        if (holder.install!=null){
            holder.textStreet.setText(holder.install.address);
            holder.textComplex.setText(holder.install.address);
            holder.textName.setText(holder.install.custname);
            holder.textScheduled.setText(holder.install.tglservice);
            holder.textStatus.setText(holder.install.sstatus);
        }
    }

    @Override
    public int getItemCount() {
        return installs!=null ? installs.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        @BindView(R.id.text_street)
        TextView textStreet;
        @BindView(R.id.text_complex)
        TextView textComplex;
        @BindView(R.id.text_name)
        TextView textName;
        @BindView(R.id.text_scheduled)
        TextView textScheduled;
        @BindView(R.id.text_status)
        TextView textStatus;
        public ResponseInstall.Install install;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            ButterKnife.bind(this, view);
        }
    }
}
